import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.jafet.editormovil',
  appName: 'Editor Avanzado Móvil',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    url: 'https://ais-dev-okg32avpve6y4w2zpirjsq-770532077300.us-west2.run.app',
    cleartext: false,
  },
  plugins: {
    PushNotifications: {
      presentationOptions: ['badge', 'sound', 'alert'],
    },
  },
};

export default config;
