# Proyecto Android APK — Editor Avanzado Móvil

Este paquete contiene la configuración lista para compilar **Editor Avanzado Móvil** (com.jafet.editormovil) en un archivo **.apk** instalable en Android, con soporte de **Notificaciones Push en tiempo real** (`POST_NOTIFICATIONS`, WebSocket y Web Push / Capacitor).

## Opción 1: Instalación directa en Android como WebAPK (sin PC, en 10 segundos)
1. Abre la URL de la aplicación en **Google Chrome para Android** (fuera de vistas previas embebidas).
2. Pulsa **Instalar APK** dentro de la app (o en el menú `⋮` de Chrome: *Instalar aplicación*).
3. Android generará e instalará automáticamente un **WebAPK nativo** con icono propio en tu cajón de apps, pantalla completa y notificaciones push.

## Opción 2: Compilar el archivo .apk en la nube (GitHub Actions, gratis)
1. Crea un repositorio en GitHub y sube el contenido de este ZIP.
2. Ve a la pestaña **Actions** y ejecuta **Compilar APK Android**.
3. Descarga el artefacto `Editor_Avanzado_M_vil-debug-apk`, descomprímelo e instala `app-debug.apk` en tu Android.

## Opción 3: Compilar .apk localmente con Android Studio / Gradle
```bash
npm install
mv android android-overrides
npx cap add android
cp -r android-overrides/. android/
rm -rf android-overrides
npx cap sync android
cd android && ./gradlew assembleDebug
```
El APK quedará en:
`android/app/build/outputs/apk/debug/app-debug.apk`
